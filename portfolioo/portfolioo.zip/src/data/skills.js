const skills = [
    "JavaScript", "Python", "PHP",
    "React.js", "Next.js", "Node.js",
    "Network Security", "Penetration Testing",
    "Wireshark", "Metasploit", "Burp Suite",
  ];
  
  export default skills;
  