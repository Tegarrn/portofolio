const projects = [
    {
      title: 'Penetration Testing UMKM Website',
      description: 'Conducted vulnerability assessment and secured online presence for a local business.',
      link: '#'
    },
    {
      title: 'Secure Login System',
      description: 'Developed a secure authentication system using React and Node.js.',
      link: '#'
    },
  ];
  
  export default projects;
  